# Google Play listing (draft)

**App name (30 max):** Emric: Running Coach
**Short description (80 max):** A running plan that adapts to how you feel, with reminders and a widget.
**Category:** Health & Fitness. **Contact email:** tyl3rbuch@outlook.com

## Full description
Emric is a running coach in your pocket. Log your runs or import them, tell it how you feel today, and get a plan for
the next seven days that adjusts to your recent training.

* A plan built from your last 28 days of training, your goal and the days you can run
* Tell the coach if you are fresh, tired, sore or ill, and the plan eases off
* Progress charts, pace trends and an estimated 5K time
* Import from Strava exports and Polar, or log by hand
* Daily reminders with today's session, and a home-screen widget (Android)
* Works offline; your log stays on your device and syncs to your account
* Chat with the coach about your plan

Emric gives general training guidance, generated partly with AI. It is not medical advice. Stop if something hurts
and talk to a health professional about injuries or health concerns.

## Data safety form (draft answers: check against your real backend)
* Collected: email address (account); fitness info (workouts, heart rate, plans, chat messages); user IDs.
* Shared with third parties: the text of coach chat and plan requests goes to Groq to generate replies; Polar data
  only if the user connects Polar. Supabase is the processor storing account data.
* Encrypted in transit: yes. Data deletion: yes, in app (Settings > Account & sync) and by web page/email.
* Not collected: location, contacts, photos, advertising ID. No ads, no analytics SDKs in the app.
* Notifications and widget data stay on the device.

## Permissions the app declares
Internet; Post notifications (reminders); Receive boot completed (restores reminders after a restart).
