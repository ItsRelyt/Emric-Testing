// Run after `npx cap add android`. Copies the widget + plugin code and resources into android/ and patches the manifest. Safe to re-run.
import fs from 'node:fs'; import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..'), a = path.join(root, 'android/app/src/main');
if (!fs.existsSync(a)) { console.error('android/ not found. Run: npx cap add android'); process.exit(1); }
const copyDir = (from, to) => { fs.mkdirSync(to, { recursive: true }); for (const f of fs.readdirSync(from)) fs.copyFileSync(path.join(from, f), path.join(to, f)); };
const n = path.join(root, 'native/android');
copyDir(path.join(n, 'java'), path.join(a, 'java/app/emric/coach'));
for (const d of ['layout', 'xml', 'drawable', 'values']) copyDir(path.join(n, 'res', d), path.join(a, 'res', d));
const mf = path.join(a, 'AndroidManifest.xml'); let m = fs.readFileSync(mf, 'utf8');
for (const p of ['POST_NOTIFICATIONS', 'RECEIVE_BOOT_COMPLETED'])
  if (!m.includes(`android.permission.${p}`)) m = m.replace('<application', `<uses-permission android:name="android.permission.${p}" />\n    <application`);
if (!m.includes('EmricWidgetProvider'))
  m = m.replace('</application>', `    <receiver android:name=".EmricWidgetProvider" android:exported="false">
            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/emric_widget_info" />
        </receiver>
    </application>`);
fs.writeFileSync(mf, m);
console.log('Native widget, plugin and manifest entries applied.');
