// Builds dist/ from www/index.html: bundles the Supabase library and the Atkinson font locally,
// so the app works offline and never contacts jsDelivr or Google Fonts.
import fs from 'node:fs'; import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..'), out = path.join(root, 'dist');
const need = (p) => { if (!fs.existsSync(p)) { console.error('Missing ' + p + '. Run: npm install'); process.exit(1); } return p; };
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(path.join(out, 'vendor'), { recursive: true });
let html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const n0 = html.length;
fs.copyFileSync(need(path.join(root, 'node_modules/@supabase/supabase-js/dist/umd/supabase.js')), path.join(out, 'vendor/supabase.js'));
html = html.replace(/<script src="https:\/\/cdn\.jsdelivr\.net\/npm\/@supabase\/supabase-js@[^"]*"><\/script>/, '<script src="vendor/supabase.js"></script>');
const fdir = need(path.join(root, 'node_modules/@fontsource/atkinson-hyperlegible/files'));
let css = '';
for (const w of [400, 700]) {
  const f = `atkinson-hyperlegible-latin-${w}-normal.woff2`;
  fs.copyFileSync(need(path.join(fdir, f)), path.join(out, 'vendor', f));
  css += `@font-face{font-family:'Atkinson Hyperlegible';font-style:normal;font-weight:${w};font-display:swap;src:url(vendor/${f}) format('woff2')}`;
}
html = html.replace(/<link rel="preconnect" href="https:\/\/fonts\.googleapis\.com">\s*/, '')
           .replace(/<link href="https:\/\/fonts\.googleapis\.com[^>]*>/, `<style>${css}</style>`);
if (/cdn\.jsdelivr|fonts\.googleapis/.test(html.replace(/<p>.*?<\/p>/gs, ''))) { console.error('External CDN reference still present in index.html'); process.exit(1); }
fs.writeFileSync(path.join(out, 'index.html'), html);
fs.copyFileSync(path.join(root, 'www/icon-192.png'), path.join(out, 'icon-192.png'));
console.log(`dist/ ready (${n0} -> ${html.length} bytes of HTML)`);
