// Supabase Edge Function: AI coach proxy. The Groq key lives only here (as a secret), never in the app.
// Deploy:  supabase functions deploy coach
//          supabase secrets set GROQ_API_KEY=gsk_...
// JWT verification stays ON (default), so only signed-in Emric users can call it.
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const ALLOWED_MODELS = new Set((Deno.env.get('ALLOWED_MODELS') ?? 'openai/gpt-oss-120b,openai/gpt-oss-20b,llama-3.3-70b-versatile,llama-3.1-8b-instant').split(',').map((s) => s.trim()));
const MAX_TOKENS = 6000;
const MAX_BODY = 200_000;

const json = (status: number, message: string) =>
  new Response(JSON.stringify({ error: { message } }), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json(405, 'Method not allowed');
  const key = Deno.env.get('GROQ_API_KEY');
  if (!key) return json(500, 'AI key is not configured on the server');

  const raw = await req.text();
  if (raw.length > MAX_BODY) return json(413, 'Request too large');
  let b: any;
  try { b = JSON.parse(raw); } catch { return json(400, 'Invalid JSON'); }
  if (!ALLOWED_MODELS.has(b.model)) return json(400, 'Model not allowed');
  if (!Array.isArray(b.messages) || b.messages.length === 0) return json(400, 'messages required');

  // Forward only the fields the app uses.
  const body: Record<string, unknown> = {
    model: b.model,
    messages: b.messages,
    temperature: typeof b.temperature === 'number' ? Math.min(Math.max(b.temperature, 0), 1) : 0.3,
    max_completion_tokens: Math.min(Number(b.max_completion_tokens) || 2000, MAX_TOKENS),
  };
  if (b.response_format?.type === 'json_object') body.response_format = { type: 'json_object' };
  if (['low', 'medium', 'high'].includes(b.reasoning_effort)) body.reasoning_effort = b.reasoning_effort;

  const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify(body),
  });
  return new Response(await r.text(), { status: r.status, headers: { ...CORS, 'Content-Type': 'application/json' } });
});
