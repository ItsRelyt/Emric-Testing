// Supabase Edge Function: permanently deletes the calling user's account and data (Google Play requirement).
// Deploy:  supabase functions deploy delete-account
// Uses the auto-provided SUPABASE_URL, SUPABASE_ANON_KEY and SUPABASE_SERVICE_ROLE_KEY. JWT verification stays ON.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const reply = (status: number, obj: unknown) => new Response(JSON.stringify(obj), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });

// Every table that holds per-user rows, keyed by its user column. ADD YOUR OTHERS (for example the table your Polar
// function stores tokens in), or give them ON DELETE CASCADE foreign keys to auth.users so they go automatically.
const USER_TABLES: Array<[string, string]> = [
  ['emric_user_data', 'user_id'],
  // ['polar_connections', 'user_id'],
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return reply(405, { error: 'Method not allowed' });
  const body = await req.json().catch(() => ({}));
  if (body.confirm !== 'DELETE') return reply(400, { error: 'Confirmation missing' });

  const url = Deno.env.get('SUPABASE_URL')!;
  const asUser = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } } });
  const { data: u, error: ue } = await asUser.auth.getUser();
  if (ue || !u?.user) return reply(401, { error: 'Not signed in' });

  const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  for (const [table, col] of USER_TABLES) {
    const { error } = await admin.from(table).delete().eq(col, u.user.id);
    if (error) return reply(500, { error: `Could not erase ${table}` });
  }
  const { error } = await admin.auth.admin.deleteUser(u.user.id);
  if (error) return reply(500, { error: 'Could not delete the account' });
  return reply(200, { ok: true });
});
