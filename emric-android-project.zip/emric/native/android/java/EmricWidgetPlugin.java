package app.emric.coach;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Bridge between the web app and the home-screen widget. */
@CapacitorPlugin(name = "EmricWidget")
public class EmricWidgetPlugin extends Plugin {

    /** update({ json }): store the next planned days and redraw every widget on the home screen. */
    @PluginMethod
    public void update(PluginCall call) {
        String json = call.getString("json");
        if (json == null) { call.reject("json is required"); return; }
        Context c = getContext();
        c.getSharedPreferences(EmricWidgetProvider.PREFS, Context.MODE_PRIVATE).edit().putString(EmricWidgetProvider.KEY, json).apply();
        EmricWidgetProvider.refreshAll(c);
        call.resolve();
    }

    /** status(): how many widgets are on the home screen. */
    @PluginMethod
    public void status(PluginCall call) {
        Context c = getContext();
        int n = AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, EmricWidgetProvider.class)).length;
        JSObject r = new JSObject();
        r.put("count", n);
        call.resolve(r);
    }

    /** requestPin(): ask the launcher to place a widget (Android 8+ launchers that support it). */
    @PluginMethod
    public void requestPin(PluginCall call) {
        Context c = getContext();
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        JSObject r = new JSObject();
        boolean supported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && m.isRequestPinAppWidgetSupported();
        boolean requested = false;
        if (supported) requested = m.requestPinAppWidget(new ComponentName(c, EmricWidgetProvider.class), null, null);
        r.put("supported", supported);
        r.put("requested", requested);
        call.resolve(r);
    }
}
