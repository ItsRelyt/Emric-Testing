package app.emric.coach;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(EmricWidgetPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
