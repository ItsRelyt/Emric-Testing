package app.emric.coach;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** Home-screen widget: today's planned session. Data comes from the web app (see EmricWidgetPlugin). */
public class EmricWidgetProvider extends AppWidgetProvider {
    static final String PREFS = "emric_widget", KEY = "payload";

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) m.updateAppWidget(id, build(c));
        scheduleMidnight(c);
    }

    @Override public void onEnabled(Context c) { scheduleMidnight(c); }

    @Override
    public void onDisabled(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(updateIntent(c));
    }

    static void refreshAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (int id : m.getAppWidgetIds(new ComponentName(c, EmricWidgetProvider.class))) m.updateAppWidget(id, build(c));
    }

    private static PendingIntent updateIntent(Context c) {
        Intent i = new Intent(c, EmricWidgetProvider.class).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, EmricWidgetProvider.class)));
        return PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Redraw just after midnight so the widget switches to the new day without the app being opened (inexact alarm, no special permission). */
    private static void scheduleMidnight(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Calendar t = Calendar.getInstance();
        t.add(Calendar.DAY_OF_YEAR, 1);
        t.set(Calendar.HOUR_OF_DAY, 0); t.set(Calendar.MINUTE, 1); t.set(Calendar.SECOND, 0); t.set(Calendar.MILLISECOND, 0);
        am.set(AlarmManager.RTC, t.getTimeInMillis(), updateIntent(c));
    }

    static RemoteViews build(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_today);
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        String label = new SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(new Date()).toUpperCase(Locale.getDefault());
        String title = "Open Emric", sub = "Sign in and ask your coach for a plan.", status = "";
        try {
            String raw = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null);
            if (raw != null) {
                JSONObject p = new JSONObject(raw);
                if (!p.optBoolean("signedIn", false)) {
                    title = "Sign in to Emric"; sub = "Your plan appears here once you are signed in.";
                } else {
                    JSONObject hit = null;
                    JSONArray days = p.optJSONArray("days");
                    for (int i = 0; days != null && i < days.length(); i++) {
                        JSONObject d = days.getJSONObject(i);
                        if (today.equals(d.optString("date"))) { hit = d; break; }
                    }
                    if (hit != null) {
                        title = hit.optString("title", "Today's session");
                        sub = hit.optString("sub", "");
                        if (today.equals(p.optString("doneDate")) && p.optBoolean("done", false)) status = "Logged \u2713";
                    } else {
                        title = "No session planned"; sub = "Open Emric to get a fresh plan.";
                    }
                }
            }
        } catch (Exception ignored) { /* show the placeholder */ }
        v.setTextViewText(R.id.w_label, "TODAY \u00B7 " + label);
        v.setTextViewText(R.id.w_title, title);
        v.setTextViewText(R.id.w_sub, sub);
        v.setViewVisibility(R.id.w_sub, sub.isEmpty() ? View.GONE : View.VISIBLE);
        v.setTextViewText(R.id.w_status, status);
        v.setViewVisibility(R.id.w_status, status.isEmpty() ? View.GONE : View.VISIBLE);
        Intent launch = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (launch != null)
            v.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 0, launch, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        return v;
    }
}
