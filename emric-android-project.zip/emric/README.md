# Emric for Android: build and release guide

The app is your web app (`www/index.html`) wrapped with Capacitor 8, plus a native Android home-screen widget.
Reminders use scheduled local notifications. **None of the Android side has been compiled or run on a device**
(it could not be built where this was prepared), so do the test pass in step 4 before uploading.

## 1. One-time setup
Needs Node 22+ and a current Android Studio (it bundles the JDK and Android SDK 36).

    npm install
    npm run setup        # builds dist/, creates android/, adds the widget code, makes icons, syncs

`npm run sync` re-does the web build + native copy after you edit `www/index.html`.

## 2. Deploy the two server functions (Supabase)
    supabase functions deploy coach
    supabase secrets set GROQ_API_KEY=gsk_your_key
    supabase functions deploy delete-account

* **coach** moves your Groq key off the phone. Until it is deployed, the app still uses the old route (key read from
  `app_settings`), which means **every signed-in user can read your key**. After deploying, delete the
  `groq_api_key` row from `app_settings`, and rotate the key, since it has already been exposed to users.
* **delete-account** powers Settings > Delete my account (Google Play requires it). Open
  `supabase/functions/delete-account/index.ts` and add every table that stores per-user data
  (for example wherever your Polar function keeps tokens) to `USER_TABLES`, or give them
  `ON DELETE CASCADE` foreign keys to `auth.users`.

## 3. Things to know about this setup
* **App ID `app.emric.coach`** is permanent once published. Change it in `capacitor.config.json` *and* the
  `package app.emric.coach;` lines in `native/android/java/*.java` before the first `npm run setup` if you want another.
* **`server.hostname` is `emric.app`**, so the in-app origin matches your existing Polar redirect URI
  (`https://emric.app/`). `allowNavigation` lets the WebView go to `*.polar.com` and come back. Test Polar sign-in.
* The build bundles the Supabase library and the Atkinson font, so the app makes no CDN requests.
* Target API is Android 16 (API 36), required for new apps since 31 Aug 2026; Capacitor 8 sets this.
* Status-bar icons: config uses `"style": "LIGHT"` (dark icons on your light background). Confirm on a device.

## 4. Test pass (physical phone, plus an Android 13+ device)
1. Install a debug build: Run in Android Studio.
2. Sign in, get a plan, open Settings > Reminders & widget, enable reminders (permission prompt), tap
   *Send a test reminder*. Tap the notification: the app should open on Coach.
3. Set the reminder a few minutes ahead, background the app, confirm it arrives. Log today's workout: today's
   reminder should not fire.
4. *Add widget* should show the launcher's confirm prompt. Check it shows today's session, and changes after midnight.
5. Back button: closes sheets first, steps to Coach, then leaves the app. Export CSV opens the share sheet.
6. Turn on airplane mode, reopen: the app and the last plan still load.
7. Delete a throwaway account end to end.

## 5. Release build
Android Studio > Build > Generate Signed App Bundle (AAB). Create an upload keystore, **back it up**, and enrol in Play
App Signing. Raise `versionCode` in `android/app/build.gradle` for every upload.

## 6. Play Console checklist
* Upload `store/play-icon-512.png`, `store/feature-graphic-1024x500.png` and the five `store/screenshot-*.png`
  (these use demo data). Text is in `store/listing.md`.
* **Privacy policy URL:** host `store/privacy.html` (for example `https://emric.app/privacy.html`). Use the same page,
  `#delete-account`, as the account-deletion URL in the Data safety form.
* Data safety answers and category notes are in `store/listing.md`.
* Declare Health & Fitness; the policy text already says coaching is not medical advice.
* If your developer account is a *personal* one created after Nov 2023, Google requires a closed test with
  12+ testers for 14 days before production. Check your Play Console to confirm.

## 7. Reminders: how they work (and one limit)
Reminders are local notifications built from your plan: one per planned day, rebuilt whenever the plan or log changes
(and when the app opens). They reach at most 14 days ahead and end with a "Keep your reminders going" nudge, so someone
who never opens the app stops getting reminders after the plan runs out. No Firebase or server push is involved.
Exact alarms are not requested (Play restricts them), so Android may deliver a reminder a few minutes late.
If you later want server-sent push (for example "your coach updated your plan"), that needs Firebase Cloud Messaging.
